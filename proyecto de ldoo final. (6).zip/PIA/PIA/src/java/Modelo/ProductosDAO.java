/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author osnap
 */
public class ProductosDAO {
    private Connection conexion;
    
    private void abrirConexion() throws SQLException, InstantiationException, IllegalAccessException{
        try{
    Class.forName("org.mariadb.jdbc.Driver").newInstance();
    String dbURL ="jdbc:mariadb://localhost:3306/usuarios";
    //**** !NO deben almacenarse datos de conexion en el codigo!
    String username = "root";
    String password = "0600020430"; //*** !Esto NUNCA debe hacerse! :/
    conexion = DriverManager.getConnection(dbURL, username,password);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProductosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void cerrarConexion() throws SQLException{
    conexion.close();
    }
    
    public void insertar(ProductosDTO dto) {
        try{
            abrirConexion();
        String SQL = "insert into almacen values ('"+ dto.getId_producto()+"','"+ dto.getId_usuario()+ "','"+ dto.getNombre_producto()+"','"+ dto.getCantidad_producto()+"')";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(SQL);
            cerrarConexion();
        }catch(Exception e){
        e.printStackTrace();
        }
    }
    
        public List<ProductosDTO> buscar(Productos dt){
        List <ProductosDTO> beans = new ArrayList();
        try{
        abrirConexion();
        String SQL = "select *from almacen where nombre_producto like '%"+dt.getNombre_producto()+ "%'";
            Statement stmt = conexion.createStatement();
            ResultSet rs= stmt.executeQuery(SQL);
            while(rs.next()){
                ProductosDTO cantidad = new ProductosDTO();
                cantidad.setId_producto(rs.getInt("Id_Producto"));
                cantidad.setId_usuario(rs.getInt("Id_Usuario"));
                cantidad.setNombre_producto(rs.getString("Nombre_Producto"));
                cantidad.setCantidad_producto(rs.getInt("Cantidad_Producto"));
                beans.add(cantidad);
            } cerrarConexion();
        }catch(Exception e){
        e.printStackTrace();
        } return beans;
    }
        
        public void actualizar(Productos dt,ProductosDTO dto) {
        try{
            abrirConexion();
        String SQL = "update almacen SET Id_Producto ='"+ dto.getId_producto()+"',Id_Usuario ='"+ dto.getId_usuario()+ "',Nombre_Producto ='"+ dto.getNombre_producto()+"',Cantidad_Producto ='"+ dto.getCantidad_producto()+"'WHERE Nombre_Producto ='"+dt.getNombre_producto()+"'";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(SQL);
            cerrarConexion();
        }catch(Exception e){
        e.printStackTrace();
        }
    }
        public void eliminar(Productos dt) {
        try{
            abrirConexion();
        String SQL = "DELETE FROM almacen WHERE Nombre_Producto ='"+dt.getNombre_producto()+"'";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(SQL);
            cerrarConexion();
        }catch(Exception e){
        e.printStackTrace();
        }
    }
         public List <ProductosDTO> mostrar() {
             List <ProductosDTO> beans = new ArrayList();
        try{
            abrirConexion();
        String SQL = "SELECT * FROM almacen";
            Statement stmt = conexion.createStatement();
            ResultSet rs =stmt.executeQuery(SQL);
                while (rs.next()){
                ProductosDTO cantidad = new ProductosDTO();
                cantidad.setId_producto(rs.getInt("Id_Producto"));
                cantidad.setId_usuario(rs.getInt("Id_Usuario"));
                cantidad.setNombre_producto(rs.getString("Nombre_Producto"));
                cantidad.setCantidad_producto(rs.getInt("Cantidad_Producto"));
                beans.add(cantidad);
             }
            cerrarConexion();
        }catch(Exception e){
        e.printStackTrace();
        }
        return beans;
    }
    
}

