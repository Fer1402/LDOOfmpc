/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Productos;
import Modelo.ProductosDAO;
import Modelo.ProductosDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author osnap
 */
public class ProductosControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String accion = request.getParameter("accion");
        
        if(accion.equals("Ingresar")){
            int id_producto = Integer.parseInt(request.getParameter("Id_Producto"));
            int id_usuario = Integer.parseInt(request.getParameter("Id_Usuario"));
            String nombre_producto = request.getParameter("Nombre_Producto");
            int cantidad_producto = Integer.parseInt(request.getParameter("Cantidad_Producto"));
            
            ProductosDAO PDAO = new ProductosDAO();
            ProductosDTO PDTO = new ProductosDTO();
            
            PDTO.setId_producto(id_producto);
            PDTO.setId_usuario(id_usuario);
            PDTO.setNombre_producto(nombre_producto);
            PDTO.setCantidad_producto(cantidad_producto);
            PDAO.insertar(PDTO);
            response.sendRedirect("actualizar.jsp");
        }
        else if(accion.equals("Buscar")){
            String nombre_producto = request.getParameter("Nombre_Producto");
                
            ProductosDAO PDAO = new ProductosDAO();
            ProductosDTO PDTO = new ProductosDTO();
            Productos P = new Productos();
                
            P.setNombre_producto(nombre_producto);
            List<ProductosDTO> beans= PDAO.buscar(P);
            request.getSession().setAttribute("cantidad", beans);
            response.sendRedirect("actualizar.jsp");
        }
        else if(accion.equals("Buscar2")){
            String nombre_producto = request.getParameter("Nombre_Producto");
                
            ProductosDAO PDAO = new ProductosDAO();
            ProductosDTO PDTO = new ProductosDTO();
            Productos P = new Productos();
                
            P.setNombre_producto(nombre_producto);
            List<ProductosDTO> beans= PDAO.buscar(P);
            request.getSession().setAttribute("cantidad", beans);
            response.sendRedirect("eliminar.jsp");
        }
        else if(accion.equals("Actualizar")){
            String nombre_producto1 = request.getParameter("Nombre_Producto1");
            int id_producto = Integer.parseInt(request.getParameter("Id_Producto"));
            int id_usuario = Integer.parseInt(request.getParameter("Id_Usuario"));
            String nombre_producto = request.getParameter("Nombre_Producto");
            int cantidad_producto = Integer.parseInt(request.getParameter("Cantidad_Producto"));
            
            ProductosDAO PDAO = new ProductosDAO();
            ProductosDTO PDTO = new ProductosDTO();
            Productos P = new Productos();
            P.setNombre_producto(nombre_producto1);
            PDTO.setId_producto(id_producto);
            PDTO.setId_usuario(id_usuario);
            PDTO.setNombre_producto(nombre_producto);
            PDTO.setCantidad_producto(cantidad_producto);
            PDAO.actualizar(P,PDTO);
            response.sendRedirect("actualizar.jsp");
            
            
        }
        else if(accion.equals("Eliminar")){
            String nombre_producto1 = request.getParameter("Nombre_Producto1");
            
            ProductosDAO PDAO = new ProductosDAO();
            Productos P = new Productos();
            P.setNombre_producto(nombre_producto1);
            PDAO.eliminar(P);
            response.sendRedirect("eliminar.jsp");
        }
         else if(accion.equals("Mostrar")){
            
            ProductosDAO PDAO = new ProductosDAO();
             List<ProductosDTO> beans= PDAO.mostrar();
            request.getSession().setAttribute("cantidad", beans);
            response.sendRedirect("actualizar.jsp");
        }
         else if(accion.equals("Mostrar2")){
            
            ProductosDAO PDAO = new ProductosDAO();
             List<ProductosDTO> beans= PDAO.mostrar();
            request.getSession().setAttribute("cantidad", beans);
            response.sendRedirect("eliminar.jsp");
        }
        else{
            response.sendRedirect("error.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}